cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "cordova-wheel-selector-plugin.plugin",
        "file": "plugins/cordova-wheel-selector-plugin/www/selectorplugin.js",
        "pluginId": "cordova-wheel-selector-plugin",
        "clobbers": [
            "SelectorCordovaPlugin"
        ],
        "runs": true
    },
    {
        "id": "cordova-plugin-device-motion.Acceleration",
        "file": "plugins/cordova-plugin-device-motion/www/Acceleration.js",
        "pluginId": "cordova-plugin-device-motion",
        "clobbers": [
            "Acceleration"
        ]
    },
    {
        "id": "cordova-plugin-device-motion.accelerometer",
        "file": "plugins/cordova-plugin-device-motion/www/accelerometer.js",
        "pluginId": "cordova-plugin-device-motion",
        "clobbers": [
            "navigator.accelerometer"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.2",
    "cordova-wheel-selector-plugin": "1.0.0",
    "cordova-plugin-device-motion": "1.2.5"
};
// BOTTOM OF METADATA
});